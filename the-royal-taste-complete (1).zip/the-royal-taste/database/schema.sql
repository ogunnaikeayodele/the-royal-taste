CREATE TABLE IF NOT EXISTS admins (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(80) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS menu_items (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL,
 description TEXT NULL,
 category VARCHAR(60) NOT NULL,
 price DECIMAL(12,2) NOT NULL DEFAULT 0,
 image_path VARCHAR(500) NULL,
 available TINYINT(1) NOT NULL DEFAULT 1,
 featured TINYINT(1) NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL,
 INDEX idx_menu_category(category), INDEX idx_menu_available(available)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reservations (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 customer_name VARCHAR(120) NOT NULL,
 phone VARCHAR(40) NOT NULL,
 email VARCHAR(190) NULL,
 reservation_date DATE NOT NULL,
 reservation_time TIME NOT NULL,
 guests TINYINT UNSIGNED NOT NULL,
 notes VARCHAR(1000) NULL,
 status ENUM('pending','confirmed','cancelled','completed') NOT NULL DEFAULT 'pending',
 created_at DATETIME NOT NULL,
 INDEX idx_reservation_date(reservation_date), INDEX idx_reservation_status(status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS gallery (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 caption VARCHAR(180) NULL,
 image_path VARCHAR(500) NOT NULL,
 sort_order INT NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
 setting_key VARCHAR(100) PRIMARY KEY,
 setting_value TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS activity_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 admin_id INT UNSIGNED NULL,
 action VARCHAR(100) NOT NULL,
 details VARCHAR(500) NULL,
 created_at DATETIME NOT NULL,
 INDEX idx_activity_created(created_at),
 CONSTRAINT fk_activity_admin FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
