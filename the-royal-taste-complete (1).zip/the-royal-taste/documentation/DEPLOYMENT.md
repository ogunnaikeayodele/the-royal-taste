THE ROYAL TASTE — INSTALLATION & DEPLOYMENT GUIDE
=================================================

PART A — CREATE YOUR MYSQL DATABASE IN CPANEL
1. Sign in to cPanel.
2. Open MySQL® Databases.
3. Create a database (cPanel may add your account prefix automatically).
4. Create a database user and a strong password.
5. Add the user to the database and grant ALL PRIVILEGES.
6. Keep the full database name, full database username and password. You will
   enter these in the installer.

PART B — UPLOAD THE PHP BACKEND
1. Extract the ZIP on your computer.
2. Open cPanel → File Manager → public_html.
3. Create a folder named royal-api.
4. Upload the contents INSIDE cpanel-backend/ into public_html/royal-api/.
   Do not upload the cpanel-backend folder itself as an extra nested folder.
5. Make sure install.php, bootstrap.php, api/, admin/, uploads/ and storage/
   are directly inside public_html/royal-api/.
6. Visit https://YOURDOMAIN.com/royal-api/install.php.
7. Enter database host (usually localhost), full database name, full database
   username, database password, admin username, admin password and the exact
   Vercel frontend origin (for example https://the-royal-taste.vercel.app).
8. Use an admin password of at least 12 characters.
9. When installation succeeds, delete install.php using File Manager.
10. Admin login: https://YOURDOMAIN.com/royal-api/admin/

PART C — DEPLOY THE FRONTEND TO VERCEL
1. Create a free account at https://vercel.com if you do not already have one.
2. Upload/import the vercel-frontend folder as a project (or deploy it from a
   Git repository).
3. After Vercel gives you the project URL, copy that exact HTTPS origin.
4. If you have not installed the backend yet, use that origin in the installer.
5. Edit vercel-frontend/config.js and replace YOURDOMAIN.com with your real
   backend domain and folder:
      API_BASE: "https://YOURDOMAIN.com/royal-api/api"
6. Deploy/redeploy the frontend. The config.js file is public by design; it
   contains only the public API address, never database credentials.

PART D — TEST THE CONNECTION
1. Open https://YOURDOMAIN.com/royal-api/api/settings in a browser. It should
   return JSON. (The API rewrite may require Apache mod_rewrite.)
2. Open your Vercel website. The menu should load from MySQL.
3. If you see a CORS error, return to the installer configuration or edit
   config.php and ensure frontend_origin exactly matches the Vercel origin:
   scheme + hostname, no trailing slash. Save and reload.
4. Add a menu item in /admin/ and reload the public site.
5. Submit a test reservation and confirm it appears in the dashboard.

API ROUTES
GET  /api/menu          Published, available menu items
GET  /api/settings      Public restaurant settings
GET  /api/gallery       Gallery images
POST /api/reservations  Create a pending reservation request

ADMIN FEATURES
- Menu item create, edit (select an existing item in the form), delete
- Image uploads and availability/featured controls
- Reservation list, search, status changes and deletion
- Gallery upload and deletion
- Restaurant contact, opening hours, social links and content settings
- Admin username/password changes
- Recent activity log

TROUBLESHOOTING
- HTTP 500: check cPanel → Errors and PHP version; select PHP 8.1 or newer.
- Database connection error: check database name/user prefixes and privileges.
- API 404: check that api/.htaccess exists and Apache mod_rewrite is enabled.
  Try the direct endpoint /api/index.php?route=settings if rewrite is unavailable.
- CORS error: the configured Vercel origin must match exactly. Preview URLs
  have different origins; use a stable production domain or update config.php.
- Images missing: check that uploads/ exists and is writable by PHP; ensure the
  backend URL is HTTPS and image paths are reachable from the frontend.
- Installer locked: it intentionally refuses to run again after success.

SECURITY & MAINTENANCE
- HTTPS is required for production.
- Remove install.php after setup; keep storage/ denied by .htaccess.
- Do not share admin credentials.
- Use cPanel phpMyAdmin → Export to back up MySQL.
- Download the uploads/ directory as a separate backup.
- Keep PHP and cPanel updated. Restrict admin access using your host's tools if
  possible. The dashboard uses session authentication and CSRF tokens.
- The API has exact-origin CORS checks. Configure only origins you control.

WHAT IS NOT INCLUDED
No card payments, email delivery, WhatsApp automation, SMS, external API or
subscription integration is implemented. Reservation submissions are saved
as pending requests only. Staff must confirm them in the admin dashboard.
