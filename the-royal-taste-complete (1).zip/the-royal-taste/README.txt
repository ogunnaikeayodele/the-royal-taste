THE ROYAL TASTE — Vercel + cPanel Restaurant Website
=====================================================

PROJECT CONTENTS
- vercel-frontend/: static responsive restaurant website for Vercel
- cpanel-backend/: PHP 8.1+ API, admin dashboard, installer and uploads
- database/schema.sql: database schema (also created by install.php)
- documentation/DEPLOYMENT.md: beginner-friendly deployment guide

IMPORTANT ARCHITECTURE
The Vercel deployment serves only HTML, CSS and JavaScript. PHP and MySQL run
on your cPanel hosting. The frontend communicates with the cPanel API over HTTPS.
Never put database credentials in the Vercel project.

QUICK START
1. Upload the contents of cpanel-backend/ into a folder on your cPanel hosting,
   for example public_html/royal-api/.
2. Visit https://YOURDOMAIN.com/royal-api/install.php and follow the installer.
3. Set the allowed frontend origin to your Vercel URL, e.g.
   https://the-royal-taste.vercel.app (no trailing slash).
4. Deploy vercel-frontend/ to Vercel.
5. Open vercel-frontend/config.js and set API_BASE to:
   https://YOURDOMAIN.com/royal-api/api
   Commit and redeploy the frontend.
6. Sign in to https://YOURDOMAIN.com/royal-api/admin/

SECURITY
- Delete or rename install.php after successful installation (the installer
  also locks itself using storage/installed.lock).
- Use HTTPS on both domains.
- Use a strong, unique admin password.
- Keep storage/ and config.php protected. The included .htaccess denies direct
  access on Apache; do not move config.php into the public frontend.
- Back up your MySQL database and uploads folder regularly.

LIMITATIONS / HONEST NOTES
- Reservation requests are stored in MySQL and can be managed in the dashboard.
  No payment gateway, email delivery, WhatsApp automation, or SMS service is
  included or claimed.
- CORS allows the exact frontend origin configured during installation.
- Vercel deployment itself requires a free Vercel account. cPanel hosting and
  a domain may have costs depending on your provider.
- Test the live API URL and database permissions on your hosting account.
