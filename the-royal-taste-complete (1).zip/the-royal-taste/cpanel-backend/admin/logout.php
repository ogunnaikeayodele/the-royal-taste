<?php
require_once __DIR__.'/../bootstrap.php';start_secure_session();
if(!empty($_SESSION['admin_id'])){try{db()->prepare("INSERT INTO activity_logs(admin_id,action,details,created_at) VALUES(?,?,?,NOW())")->execute([$_SESSION['admin_id'],'logout','Admin signed out']);}catch(Throwable $e){}}
$_SESSION=[];if(ini_get('session.use_cookies')){$p=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']);}
session_destroy();header('Location: index.php');exit;
