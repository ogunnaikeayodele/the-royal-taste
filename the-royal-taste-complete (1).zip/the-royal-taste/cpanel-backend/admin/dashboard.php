<?php
require_once __DIR__.'/../bootstrap.php';require_admin();
$pdo=db();$csrf=csrf_token();$notice='';
function log_action($action,$details=''){db()->prepare('INSERT INTO activity_logs(admin_id,action,details,created_at) VALUES(?,?,?,NOW())')->execute([$_SESSION['admin_id'],$action,$details]);}
function upload_image(string $field): ?string {
 if(empty($_FILES[$field]['name']))return null;
 $f=$_FILES[$field];if($f['error']!==UPLOAD_ERR_OK||$f['size']>5*1024*1024)throw new RuntimeException('Image upload failed or exceeds 5MB.');
 $info=getimagesize($f['tmp_name']);if(!$info)throw new RuntimeException('Only valid image files are allowed.');
 $mime=$info['mime']??'';$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'][$mime]??null;
 if(!$ext)throw new RuntimeException('Use JPG, PNG, WEBP or GIF images.');
 $dir=__DIR__.'/../uploads';if(!is_dir($dir))mkdir($dir,0755,true);
 $name=bin2hex(random_bytes(16)).'.'.$ext;if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$name))throw new RuntimeException('Could not save uploaded image.');
 return 'uploads/'.$name;
}
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  if(!hash_equals($csrf,$_POST['csrf']??''))throw new RuntimeException('Security token expired. Refresh this page.');
  $action=$_POST['action']??'';
  if($action==='menu_save'){
   $id=(int)($_POST['id']??0);$name=clean_string($_POST['name']??'',150);$desc=clean_string($_POST['description']??'',1000);$cat=clean_string($_POST['category']??'',60);$price=(float)($_POST['price']??0);
   if(!$name||$price<0||!in_array($cat,['Nigerian cuisine','Continental cuisine','Drinks','Desserts'],true))throw new RuntimeException('Check menu name, price and category.');
   $img=upload_image('image');
   if($id){$sql='UPDATE menu_items SET name=?,description=?,category=?,price=?,available=?,featured=?'.($img?',image_path=?':'').' WHERE id=?';$args=[$name,$desc,$cat,$price,isset($_POST['available'])?1:0,isset($_POST['featured'])?1:0];if($img)$args[]=$img;$args[]=$id;$pdo->prepare($sql)->execute($args);}
   else{$pdo->prepare('INSERT INTO menu_items(name,description,category,price,image_path,available,featured,created_at) VALUES(?,?,?,?,?,?,?,NOW())')->execute([$name,$desc,$cat,$price,$img,isset($_POST['available'])?1:0,isset($_POST['featured'])?1:0]);}
   log_action('menu_save',$name);$notice='Menu item saved.';
  }elseif($action==='menu_delete'){$id=(int)$_POST['id'];$pdo->prepare('DELETE FROM menu_items WHERE id=?')->execute([$id]);log_action('menu_delete','Item #'.$id);$notice='Menu item deleted.';}
  elseif($action==='gallery_add'){$img=upload_image('image');if(!$img)throw new RuntimeException('Choose an image.');$cap=clean_string($_POST['caption']??'',180);$pdo->prepare('INSERT INTO gallery(caption,image_path,sort_order,created_at) VALUES(?,?,0,NOW())')->execute([$cap,$img]);log_action('gallery_add',$cap);$notice='Gallery image uploaded.';}
  elseif($action==='gallery_delete'){$id=(int)$_POST['id'];$pdo->prepare('DELETE FROM gallery WHERE id=?')->execute([$id]);log_action('gallery_delete','Image #'.$id);$notice='Gallery image deleted.';}
  elseif($action==='reservation_status'){$id=(int)$_POST['id'];$status=$_POST['status']??'';if(!in_array($status,['pending','confirmed','cancelled','completed'],true))throw new RuntimeException('Invalid status.');$pdo->prepare('UPDATE reservations SET status=? WHERE id=?')->execute([$status,$id]);log_action('reservation_status','Reservation #'.$id.' '.$status);$notice='Reservation updated.';}
  elseif($action==='reservation_delete'){$id=(int)$_POST['id'];$pdo->prepare('DELETE FROM reservations WHERE id=?')->execute([$id]);log_action('reservation_delete','Reservation #'.$id);$notice='Reservation deleted.';}
  elseif($action==='settings_save'){
   $keys=['about_text','opening_hours','phone','email','address','footer_text','instagram','facebook','tiktok'];
   $st=$pdo->prepare('INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
   foreach($keys as $k){$v=clean_string($_POST[$k]??'',2000);if($k==='email'&&$v&&!filter_var($v,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Enter a valid email address.');$st->execute([$k,$v]);}
   log_action('settings_save','Website settings');$notice='Website settings updated.';
  }elseif($action==='account_save'){
   $username=clean_string($_POST['username']??'',80);$newpass=(string)($_POST['new_password']??'');
   if(strlen($username)<3)throw new RuntimeException('Username must contain at least 3 characters.');
   if($newpass!==''&&strlen($newpass)<12)throw new RuntimeException('New password must be at least 12 characters.');
   if($newpass){$pdo->prepare('UPDATE admins SET username=?,password_hash=? WHERE id=?')->execute([$username,password_hash($newpass,PASSWORD_DEFAULT),$_SESSION['admin_id']]);}
   else{$pdo->prepare('UPDATE admins SET username=? WHERE id=?')->execute([$username,$_SESSION['admin_id']]);}
   $_SESSION['admin_username']=$username;log_action('account_save','Admin credentials changed');$notice='Admin account updated.';
  }
 }catch(Throwable $e){$notice='Error: '.$e->getMessage();}
}
$counts=[];foreach(['menu_items','reservations'] as $t)$counts[$t]=(int)$pdo->query("SELECT COUNT(*) FROM $t")->fetchColumn();
foreach(['pending','confirmed','cancelled'] as $s){$q=$pdo->prepare('SELECT COUNT(*) FROM reservations WHERE status=?');$q->execute([$s]);$counts[$s]=(int)$q->fetchColumn();}
$items=$pdo->query('SELECT * FROM menu_items ORDER BY id DESC LIMIT 100')->fetchAll();
$editItem=null;
if(isset($_GET['edit'])){$eq=$pdo->prepare('SELECT * FROM menu_items WHERE id=?');$eq->execute([(int)$_GET['edit']]);$editItem=$eq->fetch() ?: null;}
$bookings=$pdo->query('SELECT * FROM reservations ORDER BY reservation_date DESC,reservation_time DESC LIMIT 100')->fetchAll();
$gallery=$pdo->query('SELECT * FROM gallery ORDER BY id DESC LIMIT 50')->fetchAll();
$settings=[];foreach($pdo->query('SELECT setting_key,setting_value FROM settings') as $r)$settings[$r['setting_key']]=$r['setting_value'];
$logs=$pdo->query('SELECT * FROM activity_logs ORDER BY id DESC LIMIT 15')->fetchAll();
function val($a,$k){return htmlspecialchars($a[$k]??'',ENT_QUOTES,'UTF-8');}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Royal Taste Admin</title><link rel="stylesheet" href="style.css"></head><body>
<header class="top"><strong>THE ROYAL TASTE / ADMIN</strong><span><?=htmlspecialchars($_SESSION['admin_username'])?> <a href="logout.php">Logout</a></span></header>
<div class="layout"><aside><a href="#overview">Overview</a><a href="#menu">Menu</a><a href="#reservations">Reservations</a><a href="#gallery">Gallery</a><a href="#settings">Website settings</a><a href="#account">Admin account</a><a href="#activity">Activity log</a></aside><main>
<?php if($notice):?><div class="notice"><?=htmlspecialchars($notice)?></div><?php endif;?>
<h1 id="overview">Dashboard overview</h1><div class="cards"><?php foreach(['menu_items'=>'Menu items','reservations'=>'Reservations','pending'=>'Pending','confirmed'=>'Confirmed','cancelled'=>'Cancelled'] as $k=>$label):?><div class="stat"><?=htmlspecialchars($label)?><strong><?=$counts[$k]?></strong></div><?php endforeach;?></div>
<section class="panel" id="menu"><h2>Menu management</h2><p class="muted">Add and edit food, drinks and desserts. Uploads accept JPG, PNG, WEBP or GIF up to 5MB.</p>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=$csrf?>"><input type="hidden" name="action" value="menu_save"><label>Existing item to edit<select name="id"><option value="0">Create new item</option><?php foreach($items as $i):?><option value="<?=$i['id']?>" <?=($editItem && (int)$editItem['id']===(int)$i['id'])?'selected':''?>><?=val($i,'name')?> (ID <?=$i['id']?>)</option><?php endforeach;?></select></label><div class="grid"><label>Item name<input name="name" value="<?=val($editItem??[],'name')?>" required></label><label>Price (NGN)<input type="number" name="price" value="<?=val($editItem??[],'price')?>" min="0" step="0.01" required></label><label>Category<select name="category"><?php foreach(['Nigerian cuisine','Continental cuisine','Drinks','Desserts'] as $cat):?><option <?=($editItem && $editItem['category']===$cat)?'selected':''?>><?=$cat?></option><?php endforeach;?></select></label><label>Picture<input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif"></label></div><label>Description<textarea name="description" rows="2"><?=val($editItem??[],'description')?></textarea></label><label><input type="checkbox" name="available" <?=(!$editItem || $editItem['available'])?'checked':''?> style="width:auto;display:inline"> Available</label><label><input type="checkbox" name="featured" <?=($editItem && $editItem['featured'])?'checked':''?> style="width:auto;display:inline"> Featured</label><button>Save menu item</button></form>
<table><tr><th>Item</th><th>Category</th><th>Price</th><th>Available</th><th>Delete</th></tr><?php foreach($items as $i):?><tr><td><?=val($i,'name')?> <a href="?edit=<?=$i['id']?>#menu">Edit</a></td><td><?=val($i,'category')?></td><td>₦<?=number_format((float)$i['price'],2)?></td><td><?=$i['available']?'Yes':'No'?></td><td><form method="post" onsubmit="return confirm('Delete this item?')"><input type="hidden" name="csrf" value="<?=$csrf?>"><input type="hidden" name="action" value="menu_delete"><input type="hidden" name="id" value="<?=$i['id']?>"><button class="small danger">Delete</button></form></td></tr><?php endforeach;?></table></section>
<section class="panel" id="reservations"><h2>Reservations</h2><form method="get"><input name="search" placeholder="Search name or phone" value="<?=htmlspecialchars($_GET['search']??'')?>"><button>Search</button></form><table><tr><th>Customer</th><th>Contact</th><th>Date / time</th><th>Guests</th><th>Status / action</th></tr><?php $search=strtolower($_GET['search']??'');foreach($bookings as $b):if($search&&!str_contains(strtolower($b['customer_name'].' '.$b['phone']),$search))continue;?><tr><td><?=val($b,'customer_name')?><br><small><?=val($b,'email')?></small></td><td><?=val($b,'phone')?></td><td><?=val($b,'reservation_date')?> <?=val($b,'reservation_time')?></td><td><?=$b['guests']?></td><td><form method="post"><input type="hidden" name="csrf" value="<?=$csrf?>"><input type="hidden" name="action" value="reservation_status"><input type="hidden" name="id" value="<?=$b['id']?>"><select name="status"><?php foreach(['pending','confirmed','cancelled','completed'] as $s):?><option <?=$b['status']===$s?'selected':''?>><?=$s?></option><?php endforeach;?></select><button class="small">Update</button></form><form method="post" onsubmit="return confirm('Delete reservation?')"><input type="hidden" name="csrf" value="<?=$csrf?>"><input type="hidden" name="action" value="reservation_delete"><input type="hidden" name="id" value="<?=$b['id']?>"><button class="small danger">Delete</button></form><small><?=val($b,'notes')?></small></td></tr><?php endforeach;?></table></section>
<section class="panel" id="gallery"><h2>Gallery management</h2><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=$csrf?>"><input type="hidden" name="action" value="gallery_add"><label>Image<input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif" required></label><label>Caption<input name="caption" maxlength="180"></label><button>Upload image</button></form><table><tr><th>Caption</th><th>Image path</th><th>Action</th></tr><?php foreach($gallery as $g):?><tr><td><?=val($g,'caption')?></td><td><?=val($g,'image_path')?></td><td><form method="post"><input type="hidden" name="csrf" value="<?=$csrf?>"><input type="hidden" name="action" value="gallery_delete"><input type="hidden" name="id" value="<?=$g['id']?>"><button class="small danger">Delete</button></form></td></tr><?php endforeach;?></table></section>
<section class="panel" id="settings"><h2>Website content and contact settings</h2><form method="post"><input type="hidden" name="csrf" value="<?=$csrf?>"><input type="hidden" name="action" value="settings_save"><?php foreach(['about_text'=>'About text','opening_hours'=>'Opening hours','phone'=>'Phone','email'=>'Email','address'=>'Physical address','footer_text'=>'Footer text','instagram'=>'Instagram URL','facebook'=>'Facebook URL','tiktok'=>'TikTok URL'] as $k=>$label):?><label><?=htmlspecialchars($label)?><textarea name="<?=$k?>" rows="2"><?=val($settings,$k)?></textarea></label><?php endforeach;?><button>Save website settings</button></form></section>
<section class="panel" id="account"><h2>Admin account</h2><form method="post"><input type="hidden" name="csrf" value="<?=$csrf?>"><input type="hidden" name="action" value="account_save"><label>New username<input name="username" value="<?=htmlspecialchars($_SESSION['admin_username'])?>" required></label><label>New password (leave blank to keep current; minimum 12 characters)<input type="password" name="new_password" minlength="12"></label><button>Update account</button></form></section>
<section class="panel" id="activity"><h2>Recent admin activity</h2><table><tr><th>Action</th><th>Details</th><th>Date</th></tr><?php foreach($logs as $l):?><tr><td><?=val($l,'action')?></td><td><?=val($l,'details')?></td><td><?=val($l,'created_at')?></td></tr><?php endforeach;?></table></section>
<p class="muted">Lists show the latest 100 menu items and reservations and latest 50 gallery images. Export database backups from cPanel → phpMyAdmin.</p>
</main></div></body></html>
