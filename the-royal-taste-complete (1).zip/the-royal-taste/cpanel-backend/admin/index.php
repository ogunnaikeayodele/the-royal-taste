<?php
require_once __DIR__.'/../bootstrap.php';
start_secure_session();
if(!empty($_SESSION['admin_id'])){header('Location: dashboard.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $u=clean_string($_POST['username']??'',80);$p=(string)($_POST['password']??'');
  $q=db()->prepare('SELECT id,username,password_hash FROM admins WHERE username=? LIMIT 1');$q->execute([$u]);$a=$q->fetch();
  if($a && password_verify($p,$a['password_hash'])){
    session_regenerate_id(true);$_SESSION['admin_id']=$a['id'];$_SESSION['admin_username']=$a['username'];$_SESSION['csrf']=bin2hex(random_bytes(32));
    db()->prepare("INSERT INTO activity_logs(admin_id,action,details,created_at) VALUES(?,?,?,NOW())")->execute([$a['id'],'login','Admin signed in']);
    header('Location: dashboard.php');exit;
  }$error='Incorrect username or password.';
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login | The Royal Taste</title><link rel="stylesheet" href="style.css"></head><body class="login"><form method="post" class="login-box"><div class="logo">THE ROYAL TASTE</div><h1>Admin sign in</h1><?php if($error):?><p class="error"><?=htmlspecialchars($error)?></p><?php endif;?><label>Username<input name="username" required autocomplete="username"></label><label>Password<input type="password" name="password" required autocomplete="current-password"></label><button>Sign in securely</button></form></body></html>
