<?php
declare(strict_types=1);
$lock=__DIR__.'/storage/installed.lock';
if(file_exists($lock)){http_response_code(403);exit('Installation is locked. Delete this application only after taking a backup; do not remove the lock casually.');}
$message='';$done=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
  $host=trim($_POST['db_host']??'localhost');$name=trim($_POST['db_name']??'');$user=trim($_POST['db_user']??'');$pass=(string)($_POST['db_pass']??'');
  $admin=trim($_POST['admin_username']??'');$password=(string)($_POST['admin_password']??'');$origin=rtrim(trim($_POST['frontend_origin']??''),'/');
  if(!$name||!$user||strlen($admin)<3||strlen($password)<12||!filter_var($origin,FILTER_VALIDATE_URL)||!preg_match('#^https://#',$origin))$message='Complete all fields. Admin password must be at least 12 characters and frontend origin must use HTTPS.';
  else try{
    $pdo=new PDO("mysql:host=$host;dbname=$name;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    $sql=file_get_contents(__DIR__.'/../database/schema.sql');
    $statements=array_filter(array_map('trim',preg_split('/;\s*(?:\r?\n|$)/',$sql)));
    foreach($statements as $statement)if($statement!=='')$pdo->exec($statement);
    $hash=password_hash($password,PASSWORD_DEFAULT);
    $st=$pdo->prepare('INSERT INTO admins(username,password_hash,created_at) VALUES(?,?,NOW())');$st->execute([$admin,$hash]);
    $defaults=[
      'about_text'=>'We believe dining should be more than a meal. It should be a moment worth remembering.',
      'opening_hours'=>'Monday – Sunday: 10:00 AM – 10:00 PM',
      'phone'=>'','email'=>'','address'=>'','footer_text'=>'An extraordinary dining experience.',
      'instagram'=>'','facebook'=>'','tiktok'=>''
    ];
    $st=$pdo->prepare('INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
    foreach($defaults as $k=>$v)$st->execute([$k,$v]);
    $cfg="<?php\nreturn ".var_export(['db_host'=>$host,'db_name'=>$name,'db_user'=>$user,'db_pass'=>$pass,'frontend_origin'=>$origin,'base_url'=>rtrim((isset($_SERVER['HTTPS'])?'https://':'http://').($_SERVER['HTTP_HOST']??'').dirname($_SERVER['SCRIPT_NAME']),'/')],true).";\n";
    if(file_put_contents(__DIR__.'/config.php',$cfg,LOCK_EX)===false)throw new RuntimeException('Could not write config.php. Check folder permissions.');
    if(!is_dir(__DIR__.'/storage'))mkdir(__DIR__.'/storage',0750,true);
    file_put_contents($lock,date('c'));
    $done=true;$message='Installation complete. Your admin dashboard is ready. Remove install.php now and sign in at /admin/.';
  }catch(Throwable $e){$message='Installation failed: '.htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8');}
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>The Royal Taste Setup</title><style>
body{margin:0;background:#171512;color:#eee;font:15px Arial}.wrap{max-width:560px;margin:45px auto;padding:30px;background:#24211c;border:1px solid #9f8049}h1{font-family:Georgia;color:#d2b16e}label{display:block;margin:15px 0;color:#c9bdab;font-size:13px}input{display:block;width:100%;padding:12px;margin-top:7px;box-sizing:border-box;background:#13120f;color:#fff;border:1px solid #5b5141}button{background:#c8a45d;border:0;padding:14px 20px;font-weight:bold;cursor:pointer}.msg{padding:12px;background:#332d22;line-height:1.6}small{color:#b4a995;line-height:1.6}</style></head><body><div class="wrap"><h1>THE ROYAL TASTE</h1><p>Secure website installation</p><?php if($message):?><p class="msg"><?=htmlspecialchars($message)?></p><?php endif;?><?php if(!$done):?><form method="post">
<label>Database host<input name="db_host" value="localhost" required></label><label>Database name<input name="db_name" required></label><label>Database username<input name="db_user" required></label><label>Database password<input type="password" name="db_pass"></label><hr>
<label>Initial admin username<input name="admin_username" minlength="3" required></label><label>Initial admin password (minimum 12 characters)<input type="password" name="admin_password" minlength="12" required></label>
<label>Allowed Vercel frontend origin (HTTPS URL)<input name="frontend_origin" placeholder="https://your-project.vercel.app" required></label>
<button type="submit">Install The Royal Taste</button></form><?php endif;?><p><small>Use a MySQL database and user created in cPanel. The installer creates tables, creates the first admin, writes config.php and locks itself after success.</small></p></div></body></html>
