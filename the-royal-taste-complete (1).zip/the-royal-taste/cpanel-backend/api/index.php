<?php
require_once __DIR__.'/../bootstrap.php';
$origin=$_SERVER['HTTP_ORIGIN'] ?? '';
$allowed=$config['frontend_origin'] ?? '';
if ($origin && hash_equals($allowed,$origin)) {
  header('Access-Control-Allow-Origin: '.$allowed); header('Vary: Origin');
  header('Access-Control-Allow-Credentials: true');
}
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');
if($_SERVER['REQUEST_METHOD']==='OPTIONS'){http_response_code(204);exit;}
$path=trim((string)($_GET['route'] ?? ''),'/');
$method=$_SERVER['REQUEST_METHOD'];
if($method==='GET' && $path==='menu'){
  $q=db()->query("SELECT id,name,description,category,price,image_path,featured FROM menu_items WHERE available=1 ORDER BY featured DESC,name ASC");
  $items=$q->fetchAll();
  foreach($items as &$item){$item['image_url']=!empty($item['image_path'])?rtrim($config['base_url'],'/').'/'.ltrim($item['image_path'],'/'):null;unset($item['image_path']);}
  json_out(['success'=>true,'items'=>$items]);
}
if($method==='GET' && $path==='settings'){
  $rows=db()->query('SELECT setting_key,setting_value FROM settings')->fetchAll();$s=[];
  foreach($rows as $r)$s[$r['setting_key']]=$r['setting_value'];
  json_out(['success'=>true,'settings'=>$s]);
}
if($method==='GET' && $path==='gallery'){
  $q=db()->query('SELECT id,caption,image_path FROM gallery ORDER BY sort_order,id DESC');
  $items=$q->fetchAll();
  foreach($items as &$item){$item['image_url']=rtrim($config['base_url'],'/').'/'.ltrim($item['image_path'],'/');unset($item['image_path']);}
  json_out(['success'=>true,'items'=>$items]);
}
if($method==='POST' && $path==='reservations'){
  $d=input_json();$name=clean_string($d['customer_name']??'',120);$phone=clean_string($d['phone']??'',40);
  $email=clean_string($d['email']??'',190);$date=clean_string($d['reservation_date']??'',10);$time=clean_string($d['reservation_time']??'',5);
  $guests=filter_var($d['guests']??0,FILTER_VALIDATE_INT);$notes=clean_string($d['notes']??'',1000);
  if(!$name||!$phone||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)||!preg_match('/^\d{2}:\d{2}$/',$time)||!$guests||$guests<1||$guests>30) json_out(['success'=>false,'message'=>'Please provide a valid name, phone, date, time and guest count.'],422);
  if($email && !filter_var($email,FILTER_VALIDATE_EMAIL)) json_out(['success'=>false,'message'=>'Please enter a valid email address.'],422);
  if($date < date('Y-m-d')) json_out(['success'=>false,'message'=>'Please choose a future date.'],422);
  $q=db()->prepare("INSERT INTO reservations(customer_name,phone,email,reservation_date,reservation_time,guests,notes,status,created_at) VALUES(?,?,?,?,?,?,?,'pending',NOW())");
  $q->execute([$name,$phone,$email?:null,$date,$time,$guests,$notes]);
  json_out(['success'=>true,'message'=>'Reservation request received.'],201);
}
json_out(['success'=>false,'message'=>'Endpoint not found.'],404);
