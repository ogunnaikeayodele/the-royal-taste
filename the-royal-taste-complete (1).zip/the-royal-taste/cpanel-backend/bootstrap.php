<?php
declare(strict_types=1);
$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) { http_response_code(503); exit('Backend not installed. Run install.php first.'); }
$config = require $configFile;
date_default_timezone_set('Africa/Lagos');
function db(): PDO {
  static $pdo = null; global $config;
  if ($pdo instanceof PDO) return $pdo;
  $dsn = 'mysql:host='.$config['db_host'].';dbname='.$config['db_name'].';charset=utf8mb4';
  $pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES=>false
  ]);
  return $pdo;
}
function json_out(array $data, int $status=200): never {
  http_response_code($status); header('Content-Type: application/json; charset=utf-8');
  header('Cache-Control: no-store'); echo json_encode($data, JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE); exit;
}
function input_json(): array { $v=json_decode(file_get_contents('php://input'),true); return is_array($v)?$v:[]; }
function clean_string($v, int $max=2000): string { return mb_substr(trim((string)$v),0,$max); }
function start_secure_session(): void {
  if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Strict']);
    session_start();
  }
}
function require_admin(): void { start_secure_session(); if (empty($_SESSION['admin_id'])) json_out(['success'=>false,'message'=>'Please sign in.'],401); }
function csrf_token(): string { start_secure_session(); if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function check_csrf(): void {
  start_secure_session(); $token=$_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
  if(!$token || !hash_equals($_SESSION['csrf'] ?? '',$token)) json_out(['success'=>false,'message'=>'Security token expired. Refresh and try again.'],419);
}
function setting(string $key, string $default=''): string {
  $q=db()->prepare('SELECT setting_value FROM settings WHERE setting_key=?');$q->execute([$key]);$v=$q->fetchColumn();return $v===false?$default:(string)$v;
}
