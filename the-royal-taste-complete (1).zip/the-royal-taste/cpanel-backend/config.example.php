<?php
// Copy to config.php and fill in your cPanel database details.
// Keep this file outside public web access if your hosting layout allows it.
return [
  'db_host' => 'localhost',
  'db_name' => 'CPANEL_DATABASE_NAME',
  'db_user' => 'CPANEL_DATABASE_USER',
  'db_pass' => 'CHANGE_THIS_DATABASE_PASSWORD',
  'frontend_origin' => 'https://your-project.vercel.app',
  'base_url' => 'https://yourdomain.com/royal-api',
];
