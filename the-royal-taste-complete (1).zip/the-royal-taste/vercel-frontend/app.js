const API = (window.ROYAL_CONFIG?.API_BASE || "").replace(/\/$/, "");
const money = n => "₦" + Number(n || 0).toLocaleString("en-NG");
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
let allMenu = [], selectedCategory = "all";
async function api(path, options={}) {
  const response = await fetch(`${API}/${path}`, {headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
  const data = await response.json().catch(()=>({success:false,message:"The server returned an invalid response."}));
  if (!response.ok || data.success === false) throw new Error(data.message || "Request failed.");
  return data;
}
function renderMenu() {
  const term = document.querySelector("#menu-search").value.trim().toLowerCase();
  const items = allMenu.filter(x => (selectedCategory==="all" || x.category===selectedCategory) &&
    (`${x.name} ${x.description} ${x.category}`).toLowerCase().includes(term));
  const grid = document.querySelector("#menu-grid");
  if (!items.length) { grid.innerHTML='<p class="empty">No menu items found. Please try another search.</p>'; return; }
  grid.innerHTML = items.map(x=>`<article class="food-card"><img loading="lazy" src="${esc(x.image_url || 'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=700&q=80')}" alt="${esc(x.name)}"><div class="food-info"><div class="food-top"><h3>${esc(x.name)}</h3><span class="price">${money(x.price)}</span></div><p>${esc(x.description || "")}</p></div></article>`).join("");
}
async function loadSite() {
  if (!API || API.includes("YOURDOMAIN")) {
    document.querySelector("#menu-grid").innerHTML='<p class="empty">Connect the cPanel API by editing vercel-frontend/config.js.</p>'; return;
  }
  try {
    const [menu, settings, gallery] = await Promise.all([api("menu"),api("settings"),api("gallery")]);
    allMenu = menu.items || []; renderMenu();
    const s=settings.settings || {};
    if(s.about_text) document.querySelector("#about-text").textContent=s.about_text;
    if(s.opening_hours) document.querySelector("#hours-display").textContent=s.opening_hours;
    if(s.address) document.querySelector("#contact-address").textContent=s.address;
    if(s.phone) document.querySelector("#contact-phone").textContent=s.phone;
    if(s.email) document.querySelector("#contact-email").textContent=s.email;
    if(s.footer_text) document.querySelector("#footer-text").textContent=s.footer_text;
    const socials=[["Instagram",s.instagram],["Facebook",s.facebook],["TikTok",s.tiktok]].filter(x=>x[1]);
    document.querySelector("#social-links").innerHTML=socials.map(x=>`<a href="${esc(x[1])}" target="_blank" rel="noopener noreferrer">${esc(x[0])}</a>`).join("");
    if(gallery.items?.length) document.querySelector("#gallery-grid").innerHTML='<div class="gallery-items">'+gallery.items.map(x=>`<div class="gallery-item"><img loading="lazy" src="${esc(x.image_url)}" alt="${esc(x.caption || 'Restaurant gallery image')}"><p>${esc(x.caption || '')}</p></div>`).join("")+'</div>';
  } catch(e) { document.querySelector("#menu-grid").innerHTML=`<p class="empty">${esc(e.message)} Check that the cPanel API is online and CORS is configured.</p>`; }
}
document.querySelector("#menu-search").addEventListener("input",renderMenu);
document.querySelector("#category-filters").addEventListener("click",e=>{const b=e.target.closest("button[data-category]");if(!b)return;selectedCategory=b.dataset.category;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderMenu();});
const toggle=document.querySelector(".menu-toggle"), nav=document.querySelector(".nav");
toggle.addEventListener("click",()=>{const open=nav.classList.toggle("open");toggle.setAttribute("aria-expanded",String(open));});
nav.addEventListener("click",e=>{if(e.target.closest("a"))nav.classList.remove("open");});
document.querySelector("#reservation-form").addEventListener("submit",async e=>{
  e.preventDefault();const form=e.currentTarget,msg=document.querySelector("#reservation-message"),btn=form.querySelector("button");
  msg.textContent="Sending your request...";msg.className="form-message";btn.disabled=true;
  const payload=Object.fromEntries(new FormData(form).entries());payload.guests=Number(payload.guests);
  try{await api("reservations",{method:"POST",body:JSON.stringify(payload)});msg.textContent="Thank you. Your reservation request has been received and is pending confirmation.";msg.className="form-message success";form.reset();}
  catch(err){msg.textContent=err.message;msg.className="form-message error";}finally{btn.disabled=false;}
});
document.querySelector("#year").textContent=new Date().getFullYear();
loadSite();
