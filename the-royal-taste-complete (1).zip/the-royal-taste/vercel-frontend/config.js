// Set this to the HTTPS API URL created on your cPanel hosting.
// Example: https://example.com/royal-api/api
window.ROYAL_CONFIG = {
  API_BASE: "https://YOURDOMAIN.com/royal-api/api"
};
